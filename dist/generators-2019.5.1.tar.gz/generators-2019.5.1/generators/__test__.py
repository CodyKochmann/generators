
from generators.unittests import *

if __name__ == '__main__':
    main(verbosity=2)

